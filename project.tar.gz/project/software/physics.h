#ifndef __PHYSICS_H__
#define __PHYSICS_H__

extern void update_physics();
struct collider{ 
	struct vec2 size; 
};

#endif
